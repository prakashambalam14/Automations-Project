import pandas as pd
import os
from datetime import datetime

# ===== CONFIG =====
INPUT_FOLDER = "input_files"

today = datetime.now().strftime("%Y_%m_%d")
file_name = f"grocery_sales_{today}.csv"
file_path = os.path.join(INPUT_FOLDER, file_name)

print("Looking for file:", file_path)

if not os.path.exists(file_path):
    print("❌ ERROR: Today's grocery sales file not found!")
    exit()

# ===== LOAD DATA =====
df = pd.read_csv(file_path)

print("✅ File loaded successfully!")
print("Rows:", len(df))

# ===== DATA CLEANING =====
df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
df["unit_price"] = pd.to_numeric(df["unit_price"], errors="coerce")
df["quantity_sold"] = pd.to_numeric(df["quantity_sold"], errors="coerce")
df["total_amount"] = pd.to_numeric(df["total_amount"], errors="coerce")

df = df.dropna()
df = df[df["quantity_sold"] > 0]
df = df.drop_duplicates()

print("After cleaning rows:", len(df))


# =========================================================
#                    KPI CALCULATIONS
# =========================================================

print("\n--- KPI CALCULATIONS ---")

# 1️⃣ Total Revenue
total_revenue = df["total_amount"].sum()

# 2️⃣ Total Quantity Sold
total_quantity = df["quantity_sold"].sum()

# 3️⃣ Total Transactions
total_transactions = len(df)

# 4️⃣ Average Bill Value
avg_bill_value = total_revenue / total_transactions if total_transactions > 0 else 0

# 5️⃣ Average Selling Price
avg_selling_price = total_revenue / total_quantity if total_quantity > 0 else 0

# 6️⃣ Most Used Payment Method
top_payment = df["payment_method"].value_counts().idxmax()

# 7️⃣ Peak Sales Hour
df["hour"] = df["timestamp"].dt.hour
peak_hour = df.groupby("hour")["total_amount"].sum().idxmax()

overall_kpi = {
    "Total Revenue": round(total_revenue, 2),
    "Total Quantity Sold": total_quantity,
    "Total Transactions": total_transactions,
    "Average Bill Value": round(avg_bill_value, 2),
    "Average Selling Price": round(avg_selling_price, 2),
    "Top Payment Method": top_payment,
    "Peak Sales Hour": peak_hour
}

print("\nOverall KPIs:")
for k, v in overall_kpi.items():
    print(f"{k}: {v}")


# =========================================================
#               TOP SELLING PRODUCT
# =========================================================

top_products = (
    df.groupby("product_name")
      .agg(
          Total_Quantity=("quantity_sold", "sum"),
          Total_Revenue=("total_amount", "sum")
      )
      .sort_values(by="Total_Revenue", ascending=False)
      .reset_index()
)

top_product_name = top_products.iloc[0]["product_name"]
top_product_revenue = top_products.iloc[0]["Total_Revenue"]

print("\n🏆 Top Selling Product:")
print(top_product_name, "-", round(top_product_revenue, 2))


# =========================================================
#               CATEGORY PERFORMANCE
# =========================================================

category_kpi = (
    df.groupby("category")
      .agg(
          Total_Quantity=("quantity_sold", "sum"),
          Total_Revenue=("total_amount", "sum")
      )
      .sort_values(by="Total_Revenue", ascending=False)
      .reset_index()
)

print("\nCategory Performance:")
print(category_kpi.head())


# =========================================================
#               PAYMENT METHOD PERFORMANCE
# =========================================================

payment_kpi = (
    df.groupby("payment_method")
      .agg(
          Total_Revenue=("total_amount", "sum"),
          Transactions=("payment_method", "count")
      )
      .reset_index()
)


# =========================================================
#               GENERATE EXCEL REPORT
# =========================================================

print("\n--- Generating Excel Report ---")

REPORT_FOLDER = "reports"
os.makedirs(REPORT_FOLDER, exist_ok=True)

report_file = f"Daily_Grocery_Report_{today}.xlsx"
report_path = os.path.join(REPORT_FOLDER, report_file)

with pd.ExcelWriter(report_path, engine="openpyxl") as writer:

    # Sheet 1: Summary KPIs
    summary_df = pd.DataFrame(list(overall_kpi.items()), columns=["Metric", "Value"])
    summary_df.to_excel(writer, sheet_name="Summary_KPIs", index=False)

    # Sheet 2: Top Products
    top_products.to_excel(writer, sheet_name="Top_Products", index=False)

    # Sheet 3: Category Performance
    category_kpi.to_excel(writer, sheet_name="Category_Performance", index=False)

    # Sheet 4: Payment Performance
    payment_kpi.to_excel(writer, sheet_name="Payment_Performance", index=False)

    # Sheet 5: Raw Data
    df.to_excel(writer, sheet_name="Raw_Data", index=False)

print("✅ Grocery Excel report generated:", report_path)

# =========================================================
#                   EMAIL REPORT SECTION
# =========================================================

import smtplib
from email.message import EmailMessage

print("\n--- Sending Email Report ---")

# comment out this line 
#SENDER_EMAIL = "sender Mail"
#APP_PASSWORD = "comment out this use go to google search App Password sign your gmail and name it you will get an password paste that password here any confusion use Chatgpt"    
#RECEIVER_EMAIL =  "Receiver Mail" 

msg = EmailMessage()
msg["Subject"] = f"Daily Grocery Sales Report - {today}"
msg["From"] = SENDER_EMAIL
msg["To"] = RECEIVER_EMAIL

# Email Body Content (Summary of KPIs)
email_body = f"""
Hello,

Please find attached the Daily Grocery Sales Report for {today}.

📊 KPI Summary:

Total Revenue: ₹{round(total_revenue, 2)}
Total Transactions: {total_transactions}
Total Quantity Sold: {total_quantity}
Average Bill Value: ₹{round(avg_bill_value, 2)}
Average Selling Price: ₹{round(avg_selling_price, 2)}
Top Payment Method: {top_payment}
Peak Sales Hour: {peak_hour}:00 hrs

🏆 Top Selling Product:
{top_product_name} - ₹{round(top_product_revenue, 2)}

Regards,
Automated Grocery Reporting System
"""

msg.set_content(email_body)

# Attach Excel file
with open(report_path, "rb") as f:
    file_data = f.read()

msg.add_attachment(
    file_data,
    maintype="application",
    subtype="vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    filename=report_file
)

# Send Email
with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
    smtp.login(SENDER_EMAIL, APP_PASSWORD)
    smtp.send_message(msg)

print("✅ Email sent successfully!")

