import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import os
import random

# ===== CONFIG =====
OUTPUT_FOLDER = "input_files"

# Minimum 25 grocery products
PRODUCTS = {
    "Rice 1kg": ("Grains", 60),
    "Wheat Flour 1kg": ("Grains", 45),
    "Sugar 1kg": ("Essentials", 50),
    "Salt 1kg": ("Essentials", 20),
    "Milk 1L": ("Dairy", 28),
    "Curd 500g": ("Dairy", 35),
    "Butter 100g": ("Dairy", 52),
    "Eggs 12pcs": ("Poultry", 75),
    "Bread": ("Bakery", 30),
    "Biscuits": ("Snacks", 25),
    "Cooking Oil 1L": ("Essentials", 120),
    "Toor Dal 1kg": ("Grains", 110),
    "Chana Dal 1kg": ("Grains", 90),
    "Tomato 1kg": ("Vegetables", 30),
    "Onion 1kg": ("Vegetables", 35),
    "Potato 1kg": ("Vegetables", 25),
    "Apple 1kg": ("Fruits", 120),
    "Banana 1 dozen": ("Fruits", 50),
    "Orange 1kg": ("Fruits", 80),
    "Tea Powder 250g": ("Beverages", 140),
    "Coffee 100g": ("Beverages", 95),
    "Soft Drink 1L": ("Beverages", 40),
    "Shampoo": ("Personal Care", 85),
    "Soap": ("Personal Care", 28),
    "Toothpaste": ("Personal Care", 55),
    "Detergent 1kg": ("Home Care", 110),
    "Dishwash Liquid": ("Home Care", 75)
}

PAYMENT_METHODS = ["Cash", "UPI", "Card"]

ROWS_PER_DAY = random.randint(300, 600)

# ===== CREATE OUTPUT FOLDER =====
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# ===== FILE NAME =====
today = datetime.now().strftime("%Y_%m_%d")
file_name = f"grocery_sales_{today}.csv"
file_path = os.path.join(OUTPUT_FOLDER, file_name)

# ===== GENERATE DATA =====
records = []

start_time = datetime.now().replace(hour=6, minute=0, second=0)
end_time = datetime.now().replace(hour=22, minute=0, second=0)

for i in range(ROWS_PER_DAY):

    timestamp = start_time + timedelta(
        minutes=random.randint(0, int((end_time - start_time).total_seconds() / 60))
    )

    product = random.choice(list(PRODUCTS.keys()))
    category, price = PRODUCTS[product]

    quantity = random.randint(1, 5)

    total_amount = price * quantity

    payment = random.choices(
        PAYMENT_METHODS,
        weights=[30, 50, 20]  # UPI more common
    )[0]

    records.append([
        timestamp.strftime("%Y-%m-%d %H:%M:%S"),
        product,
        category,
        price,
        quantity,
        total_amount,
        payment
    ])

# ===== CREATE DATAFRAME =====
columns = [
    "timestamp",
    "product_name",
    "category",
    "unit_price",
    "quantity_sold",
    "total_amount",
    "payment_method"
]

df = pd.DataFrame(records, columns=columns)

# ===== SAVE CSV =====
df.to_csv(file_path, index=False)

print("✅ Grocery sales data generated:", file_path)
print("Rows:", len(df))
